# -*- coding: utf-8

from distutils.core import setup
setup(name='SOLOv2',
      version='1',
      author='J. Lux',
      description='SOLOv2',
      packages=['SOLOv2'],
      )
